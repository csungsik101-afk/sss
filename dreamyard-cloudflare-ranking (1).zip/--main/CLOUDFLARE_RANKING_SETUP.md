# 꿈뜨락 Cloudflare 통합 랭킹 설정

이 프로젝트는 Cloudflare Pages Functions + D1으로 랭킹을 저장합니다.

## 1. D1 만들기
Cloudflare Dashboard → Workers & Pages → D1에서 데이터베이스를 하나 만들고 이름을 `dreamyard-rankings`로 지정합니다.

## 2. 테이블 만들기
D1 콘솔에서 `migrations/0001_rankings.sql` 내용을 실행합니다.

## 3. Pages에 D1 연결
Cloudflare Pages 프로젝트의 Settings → Functions → D1 database bindings에서
- Variable name: `DB`
- Database: 방금 만든 D1

로 연결합니다.

## 4. 배포
기존 Vite 프로젝트처럼 `npm run build` 후 Cloudflare Pages에 `dist`를 배포하면 됩니다.
`functions/api/rankings.js`는 `/api/rankings`로 자동 연결됩니다.

## 5. 랭킹 기능
- 모든 기기의 기록을 같은 D1 테이블에 저장
- 전체 TOP 10 제공
- 브라우저별 playerId를 localStorage에 보관해 '내 기록' 표시
- 같은 playerId가 다시 기록하면 더 빠른 기록만 유지
- 닉네임은 최대 16자
- 기록은 1초~30분 범위만 서버에서 허용

## 6. 개발자 코드
랭크 모드 테스트 해금 코드는 현재 `DREAMRANK`입니다.
`src/components/HomeModeSelect.tsx`에서 변경할 수 있습니다.

## 7. 주의
현재 구조는 클라이언트가 제출한 시간을 서버가 저장하는 방식이라, 완전한 치팅 방지는 아닙니다.
실제 대회용으로 강한 치팅 방지가 필요하면 게임 진행 자체를 서버 검증 방식으로 바꾸는 추가 작업이 필요합니다.
