import React, { useEffect, useState } from 'react';
import { Trophy, X, RefreshCw } from 'lucide-react';
import { fetchRankings, RankEntry } from '../utils/ranking';

interface Props { isOpen: boolean; onClose: () => void; }
const formatTime = (ms: number) => `${Math.floor(ms / 60000)}:${String(Math.floor((ms % 60000) / 1000)).padStart(2, '0')}.${String(ms % 1000).padStart(3, '0')}`;

export const RankLeaderboardModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const [top10, setTop10] = useState<RankEntry[]>([]);
  const [mine, setMine] = useState<RankEntry | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const load = async () => {
    setLoading(true); setError('');
    try { const data = await fetchRankings(); setTop10(data.top10); setMine(data.mine); }
    catch (e) { setError(e instanceof Error ? e.message : '랭킹을 불러오지 못했습니다.'); }
    finally { setLoading(false); }
  };
  useEffect(() => { if (isOpen) load(); }, [isOpen]);
  if (!isOpen) return null;

  return <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
    <div className="w-full max-w-lg bg-slate-900 border-2 border-cyan-500/40 rounded-3xl shadow-2xl overflow-hidden">
      <div className="p-5 border-b border-slate-800 flex items-center justify-between">
        <div><h2 className="text-xl font-black text-white flex items-center gap-2"><Trophy className="text-amber-400"/> 전체 랭킹 TOP 10</h2><p className="text-xs text-slate-500 mt-1">모든 기기의 랭크 기록이 하나로 집계됩니다.</p></div>
        <div className="flex gap-2"><button onClick={load} className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700"><RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`}/></button><button onClick={onClose} className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700"><X className="w-4 h-4"/></button></div>
      </div>
      <div className="p-5 space-y-2">
        {error ? <div className="p-4 rounded-xl border border-rose-500/30 bg-rose-950/30 text-rose-300 text-sm">{error}<br/><span className="text-xs text-slate-500">Cloudflare D1/Pages Functions 배포 후 사용할 수 있습니다.</span></div> : top10.length === 0 && !loading ? <div className="py-10 text-center text-slate-500">아직 등록된 기록이 없습니다.</div> : top10.map((entry) => <div key={entry.playerId} className={`flex items-center gap-3 p-3 rounded-xl border ${mine?.playerId === entry.playerId ? 'border-cyan-400/50 bg-cyan-950/20' : 'border-slate-800 bg-slate-950/50'}`}>
          <div className="w-8 text-center font-black text-amber-300">{entry.rank}</div><div className="flex-1 min-w-0"><div className="font-black text-white truncate">{entry.name}</div><div className="text-[10px] text-slate-500">{entry.className}</div></div><div className="font-mono font-black text-cyan-300">{formatTime(Number(entry.timeMs))}</div>
        </div>)}
        {mine && <div className="mt-4 p-4 rounded-2xl bg-indigo-950/30 border border-indigo-500/30 flex items-center justify-between"><div><div className="text-[10px] text-indigo-300 font-bold">내 기록</div><div className="font-black text-white">{mine.name} · {mine.className}</div></div><div className="text-right"><div className="font-black text-indigo-300">#{mine.rank}</div><div className="font-mono text-sm text-white">{formatTime(Number(mine.timeMs))}</div></div></div>}
      </div>
    </div>
  </div>;
};
