import React, { useState } from 'react';
import { motion } from 'motion/react';
import { BookOpen, Flame, Trophy, Swords, Zap, Skull, Scroll, ShieldAlert, Code2, ListOrdered } from 'lucide-react';
import { sound } from '../utils/sound';
import { GameModeType } from '../types/game';

interface HomeModeSelectProps {
  isOpen: boolean;
  onSelect: (mode: GameModeType) => void;
  rankUnlocked: boolean;
  onUnlockRank: () => void;
  onOpenLeaderboard: () => void;
}

export const HomeModeSelect: React.FC<HomeModeSelectProps> = ({ isOpen, onSelect, rankUnlocked, onUnlockRank, onOpenLeaderboard }) => {
  const [selectedMode, setSelectedMode] = useState<GameModeType>('HARDCORE');
  const [showCode, setShowCode] = useState(false);
  const [code, setCode] = useState('');
  const [codeMessage, setCodeMessage] = useState('');

  if (!isOpen) return null;

  const handleStart = () => {
    sound.playLevelUp && sound.playLevelUp();
    onSelect(selectedMode);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/95 backdrop-blur-md overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="w-full max-w-5xl bg-slate-900 border-2 border-slate-800 rounded-3xl overflow-hidden shadow-2xl relative my-8"
      >
        {/* Decorative glowing gradient backgrounds */}
        <div className="absolute top-0 left-1/4 w-72 h-72 bg-indigo-500/10 rounded-full blur-[100px] pointer-events-none" />
        <div className="absolute bottom-0 right-1/4 w-72 h-72 bg-rose-500/10 rounded-full blur-[100px] pointer-events-none" />

        <div className="p-6 sm:p-10 text-center relative z-10">
          <span className="inline-block px-3 py-1 bg-amber-500/10 border border-amber-500/30 rounded-full text-amber-400 text-xs font-bold uppercase tracking-wider mb-3">
            Game Mode Selection
          </span>
          <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight mb-2">
            별빛 마을 용사기
          </h2>
          <p className="text-sm sm:text-base text-slate-400 max-w-xl mx-auto mb-8">
            마을의 평화를 위해 몰려오는 위험에 대비하세요.<br />
            원하는 모드를 선택하여 전투를 시작하세요.
          </p>

          {/* Mode Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-10 text-left">
            {/* Story Mode Card */}
            <motion.div
              whileHover={{ scale: 1.015 }}
              onClick={() => {
                setSelectedMode('STORY');
                sound.playHit && sound.playHit();
              }}
              className={`relative cursor-pointer rounded-2xl border-2 p-5 transition-all overflow-hidden flex flex-col justify-between ${
                selectedMode === 'STORY'
                  ? 'border-indigo-500 bg-indigo-950/30 shadow-[0_0_20px_rgba(99,102,241,0.25)]'
                  : 'border-slate-800 bg-slate-950/40 hover:border-slate-700 hover:bg-slate-950/60'
              }`}
            >
              {selectedMode === 'STORY' && (
                <div className="absolute top-0 right-0 bg-indigo-500 text-white text-[10px] font-black px-3 py-1 rounded-bl-xl tracking-wider uppercase">
                  ACTIVE
                </div>
              )}

              <div>
                <div className="flex items-center gap-3 mb-3.5">
                  <div className={`p-2.5 rounded-xl border ${selectedMode === 'STORY' ? 'bg-indigo-500/20 border-indigo-500/30 text-indigo-400' : 'bg-slate-800/80 border-slate-700/50 text-slate-400'}`}>
                    <BookOpen className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-lg font-extrabold text-slate-100">스토리 모드</h3>
                    <p className="text-xs text-indigo-400 font-bold">마을 구출 정규 스테이지</p>
                  </div>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed mb-4">
                  점점 강력해지는 몬스터의 정규 공세를 이겨내는 모드입니다. 웨이브 단위로 성장하는 즐거움을 느껴보세요!
                </p>
              </div>

              <div className="space-y-1.5 pt-3 border-t border-slate-800/80 text-[11px] text-slate-400">
                <div className="flex items-center gap-1.5">
                  <span className="text-indigo-400">✔</span> 단계별 정규 웨이브 시스템
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-indigo-400">✔</span> 다양한 업적 & 퀘스트
                </div>
              </div>
            </motion.div>

            {/* Brawl Mode Card */}
            <motion.div
              whileHover={{ scale: 1.015 }}
              onClick={() => {
                setSelectedMode('BRAWL');
                sound.playHit && sound.playHit();
              }}
              className={`relative cursor-pointer rounded-2xl border-2 p-5 transition-all overflow-hidden flex flex-col justify-between ${
                selectedMode === 'BRAWL'
                  ? 'border-orange-500 bg-orange-950/30 shadow-[0_0_20px_rgba(249,115,22,0.25)]'
                  : 'border-slate-800 bg-slate-950/40 hover:border-slate-700 hover:bg-slate-950/60'
              }`}
            >
              {selectedMode === 'BRAWL' && (
                <div className="absolute top-0 right-0 bg-orange-500 text-white text-[10px] font-black px-3 py-1 rounded-bl-xl tracking-wider uppercase">
                  ACTIVE
                </div>
              )}

              <div>
                <div className="flex items-center gap-3 mb-3.5">
                  <div className={`p-2.5 rounded-xl border ${selectedMode === 'BRAWL' ? 'bg-orange-500/20 border-orange-500/30 text-orange-400' : 'bg-slate-800/80 border-slate-700/50 text-slate-400'}`}>
                    <Flame className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-lg font-extrabold text-slate-100">난투 모드</h3>
                    <p className="text-xs text-orange-400 font-bold">5분간의 무한 공세</p>
                  </div>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed mb-4">
                  조무래기들이 쉬지 않고 수없이 떼지어 몰려옵니다! 5분 동안 살벌한 공세를 견뎌낸 뒤 최종 보스 군단을 제압하세요.
                </p>
              </div>

              <div className="space-y-1.5 pt-3 border-t border-slate-800/80 text-[11px] text-slate-400">
                <div className="flex items-center gap-1.5">
                  <span className="text-orange-400">🔥</span> 조무래기 무한 대난투
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-orange-400">⏳</span> 5분 후 전 보스 동시 출현
                </div>
              </div>
            </motion.div>

            {/* Hardcore Mode Card (NEW) */}
            <motion.div
              whileHover={{ scale: 1.015 }}
              onClick={() => {
                setSelectedMode('HARDCORE');
                sound.playHit && sound.playHit();
              }}
              className={`relative cursor-pointer rounded-2xl border-2 p-5 transition-all overflow-hidden flex flex-col justify-between ${
                selectedMode === 'HARDCORE'
                  ? 'border-red-500 bg-red-950/40 shadow-[0_0_25px_rgba(239,68,68,0.35)]'
                  : 'border-slate-800 bg-slate-950/40 hover:border-slate-700 hover:bg-slate-950/60'
              }`}
            >
              <div className="absolute top-0 right-0 bg-red-600 text-white text-[10px] font-black px-3 py-1 rounded-bl-xl tracking-wider uppercase flex items-center gap-1">
                <span>NEW</span>
                <span>💀</span>
              </div>

              <div>
                <div className="flex items-center gap-3 mb-3.5">
                  <div className={`p-2.5 rounded-xl border ${selectedMode === 'HARDCORE' ? 'bg-red-500/20 border-red-500/40 text-red-400' : 'bg-slate-800/80 border-slate-700/50 text-slate-400'}`}>
                    <Skull className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-lg font-extrabold text-white flex items-center gap-1.5">
                      하드코어 모드
                    </h3>
                    <p className="text-xs text-red-400 font-bold">설계도 빌드 & 보스 「 ERROR」</p>
                  </div>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed mb-4">
                  시작 시 <strong className="text-amber-300">선택 설계도 쿠폰 3개</strong> 지급! 원하는 3종 장비를 조합하고, <strong className="text-cyan-300">대시 회피 기동</strong>으로 5페이즈 보스 「 ERROR」를 처치하세요.
                </p>
              </div>

              <div className="space-y-1.5 pt-3 border-t border-slate-800/80 text-[11px] text-slate-400">
                <div className="flex items-center gap-1.5">
                  <span className="text-amber-400">📜</span> 3개 쿠폰으로 자유 설계도 빌드
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-cyan-400">⚡</span> Space / Shift 고속 대시 회피
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-red-400">👾</span> 보스 「 ERROR」 5단계 페이즈 (약 5분)
                </div>
              </div>
            </motion.div>
          </div>

          {/* Rank Mode Card */}
          <motion.div
            whileHover={{ scale: rankUnlocked ? 1.015 : 1 }}
            onClick={() => { if (rankUnlocked) { setSelectedMode('RANK'); sound.playHit && sound.playHit(); } }}
            className={`relative cursor-pointer rounded-2xl border-2 p-5 transition-all overflow-hidden flex flex-col justify-between ${
              selectedMode === 'RANK' ? 'border-cyan-400 bg-cyan-950/30 shadow-[0_0_25px_rgba(34,211,238,0.25)]' : rankUnlocked ? 'border-slate-800 bg-slate-950/40 hover:border-slate-700 hover:bg-slate-950/60' : 'border-slate-900 bg-slate-950/20 opacity-60 cursor-not-allowed'
            }`}
          >
            <div className="absolute top-0 right-0 bg-cyan-600 text-slate-950 text-[10px] font-black px-3 py-1 rounded-bl-xl tracking-wider uppercase flex items-center gap-1">🏆 RANK</div>
            <div>
              <div className="flex items-center gap-3 mb-3.5">
                <div className={`p-2.5 rounded-xl border ${selectedMode === 'RANK' ? 'bg-cyan-500/20 border-cyan-500/40 text-cyan-300' : 'bg-slate-800/80 border-slate-700/50 text-slate-400'}`}><Trophy className="w-5 h-5" /></div>
                <div><h3 className="text-lg font-extrabold text-white">랭크 모드</h3><p className="text-xs text-cyan-400 font-bold">최종 보스 별빛 · 타임어택</p></div>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed mb-4">최종 보스 <strong className="text-cyan-300">별빛</strong>만 상대합니다. 시작 시 스킬을 <strong className="text-amber-300">20회 선택</strong>하고, 실제 전투 시간이 기록됩니다.</p>
            </div>
            <div className="space-y-1.5 pt-3 border-t border-slate-800/80 text-[11px] text-slate-400">
              <div className="flex items-center gap-1.5"><span className="text-cyan-400">⚡</span> 여러 기기의 기록을 하나의 랭킹으로 통합</div>
              <div className="flex items-center gap-1.5"><span className="text-amber-400">🎯</span> 전체 TOP 10 · 내 기록/순위</div>
              {!rankUnlocked && <div className="flex items-center gap-1.5"><span>🔒</span> 스토리 클리어 후 해금</div>}
            </div>
          </motion.div>

          <div className="flex justify-center gap-2 mt-4">
            <button onClick={() => setShowCode(true)} className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-bold text-slate-300 flex items-center gap-1.5"><Code2 className="w-4 h-4"/> CODE</button>
            <button onClick={onOpenLeaderboard} className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-bold text-slate-300 flex items-center gap-1.5"><ListOrdered className="w-4 h-4"/> 랭킹 보기</button>
          </div>

          {showCode && <div className="fixed inset-0 z-[80] flex items-center justify-center p-4 bg-black/70" onClick={() => setShowCode(false)}>
            <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-2xl p-5" onClick={(e) => e.stopPropagation()}>
              <h3 className="font-black text-white mb-1">개발자 CODE</h3><p className="text-xs text-slate-500 mb-4">랭크 모드 테스트 해금용</p>
              <input autoFocus value={code} onChange={(e) => setCode(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') { if (code.trim().toUpperCase() === 'DREAMRANK') { onUnlockRank(); setSelectedMode('RANK'); setCodeMessage('랭크 모드가 해금되었습니다.'); } else setCodeMessage('코드가 올바르지 않습니다.'); } }} placeholder="CODE 입력" className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white outline-none focus:border-cyan-400" />
              {codeMessage && <p className="text-xs mt-2 text-cyan-300">{codeMessage}</p>}
              <button onClick={() => { if (code.trim().toUpperCase() === 'DREAMRANK') { onUnlockRank(); setSelectedMode('RANK'); setCodeMessage('랭크 모드가 해금되었습니다.'); } else setCodeMessage('코드가 올바르지 않습니다.'); }} className="w-full mt-3 py-2.5 rounded-xl bg-cyan-500 text-slate-950 font-black">해금</button>
            </div>
          </div>}

          {/* Confirm Button */}
          <div className="flex flex-col items-center gap-3">
            <button
              onClick={handleStart}
              className={`w-full max-w-md py-4 px-8 rounded-2xl text-slate-950 font-black tracking-wider text-base sm:text-lg transition-all cursor-pointer ${
                selectedMode === 'STORY'
                  ? 'bg-gradient-to-r from-indigo-400 to-indigo-500 hover:from-indigo-300 hover:to-indigo-400 shadow-[0_4px_25px_rgba(99,102,241,0.3)]'
                  : selectedMode === 'BRAWL'
                  ? 'bg-gradient-to-r from-orange-400 to-orange-500 hover:from-orange-300 hover:to-orange-400 shadow-[0_4px_25px_rgba(249,115,22,0.3)]'
                  : selectedMode === 'RANK'
                  ? 'bg-gradient-to-r from-cyan-400 to-indigo-500 hover:from-cyan-300 hover:to-indigo-400 shadow-[0_4px_25px_rgba(34,211,238,0.3)]'
                  : 'bg-gradient-to-r from-red-500 via-rose-500 to-amber-500 hover:from-red-400 hover:to-amber-400 text-white shadow-[0_4px_25px_rgba(239,68,68,0.4)]'
              }`}
            >
              {selectedMode === 'STORY'
                ? '스토리 모드로 진입하기'
                : selectedMode === 'BRAWL'
                ? '난투 모드로 진입하기'
                : selectedMode === 'RANK'
                ? '랭크 모드로 진입하기 🏆'
                : '하드코어 모드로 진입하기 💀'}
            </button>
            <p className="text-xs text-slate-500">
              선택 후 클래스를 지정하면 해당 모드로 게임이 시작됩니다.
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

