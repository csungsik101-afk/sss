export interface RankEntry {
  rank: number;
  name: string;
  timeMs: number;
  className: string;
  createdAt: string;
  playerId?: string;
}

const PLAYER_ID_KEY = 'dreamyard_rank_player_id';
const PLAYER_NAME_KEY = 'dreamyard_rank_player_name';

export const getRankApiUrl = () => (import.meta.env.VITE_RANK_API_URL || '/api/rankings').replace(/\/$/, '');

export const getPlayerId = () => {
  const existing = localStorage.getItem(PLAYER_ID_KEY);
  if (existing) return existing;
  const id = typeof crypto !== 'undefined' && 'randomUUID' in crypto
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  localStorage.setItem(PLAYER_ID_KEY, id);
  return id;
};

export const getSavedRankName = () => localStorage.getItem(PLAYER_NAME_KEY) || '';
export const saveRankName = (name: string) => localStorage.setItem(PLAYER_NAME_KEY, name);

export const fetchRankings = async (): Promise<{ top10: RankEntry[]; mine: RankEntry | null }> => {
  const res = await fetch(`${getRankApiUrl()}?playerId=${encodeURIComponent(getPlayerId())}`);
  if (!res.ok) throw new Error('랭킹을 불러오지 못했습니다.');
  return res.json();
};

export const submitRank = async (payload: { name: string; timeMs: number; className: string }) => {
  const res = await fetch(getRankApiUrl(), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ...payload, playerId: getPlayerId() }),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data?.error || '랭킹 등록에 실패했습니다.');
  return data as { rank: number; bestTimeMs: number; improved: boolean };
};
