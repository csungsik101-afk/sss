const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
});

export async function onRequestGet(context) {
  const playerId = new URL(context.request.url).searchParams.get('playerId') || '';
  const top = await context.env.DB.prepare(
    `SELECT player_id as playerId, name, time_ms as timeMs, class_name as className, created_at as createdAt
     FROM rankings ORDER BY time_ms ASC, created_at ASC LIMIT 10`
  ).all();
  let mine = null;
  if (playerId) {
    mine = await context.env.DB.prepare(
      `SELECT player_id as playerId, name, time_ms as timeMs, class_name as className, created_at as createdAt,
              (SELECT COUNT(*) + 1 FROM rankings r2 WHERE r2.time_ms < rankings.time_ms) as rank
       FROM rankings WHERE player_id = ? ORDER BY time_ms ASC LIMIT 1`
    ).bind(playerId).first();
  }
  return json({
    top10: (top.results || []).map((row, i) => ({ ...row, rank: i + 1 })),
    mine,
  });
}

export async function onRequestPost(context) {
  let body;
  try { body = await context.request.json(); } catch { return json({ error: '잘못된 요청입니다.' }, 400); }
  const playerId = String(body?.playerId || '').trim();
  const name = String(body?.name || '').trim().slice(0, 16);
  const timeMs = Number(body?.timeMs);
  const className = String(body?.className || '').trim().slice(0, 20);

  if (!playerId || !name || !Number.isFinite(timeMs) || !Number.isFinite(timeMs) || timeMs < 1000 || timeMs > 30 * 60 * 1000) {
    return json({ error: '랭킹 데이터가 올바르지 않습니다.' }, 400);
  }

  const existing = await context.env.DB.prepare(
    `SELECT time_ms as timeMs FROM rankings WHERE player_id = ? LIMIT 1`
  ).bind(playerId).first();

  if (existing && Number(existing.timeMs) <= timeMs) {
    const rankRow = await context.env.DB.prepare(
      `SELECT COUNT(*) + 1 as rank FROM rankings WHERE time_ms < ?`
    ).bind(existing.timeMs).first();
    return json({ rank: Number(rankRow?.rank || 0), bestTimeMs: Number(existing.timeMs), improved: false });
  }

  await context.env.DB.prepare(
    `INSERT INTO rankings (player_id, name, time_ms, class_name, created_at)
     VALUES (?, ?, ?, ?, datetime('now'))
     ON CONFLICT(player_id) DO UPDATE SET
       name = excluded.name,
       time_ms = excluded.time_ms,
       class_name = excluded.class_name,
       created_at = excluded.created_at`
  ).bind(playerId, name, Math.round(timeMs), className || '미상').run();

  const rankRow = await context.env.DB.prepare(
    `SELECT COUNT(*) + 1 as rank FROM rankings WHERE time_ms < ?`
  ).bind(Math.round(timeMs)).first();

  return json({ rank: Number(rankRow?.rank || 0), bestTimeMs: Math.round(timeMs), improved: true });
}
