CREATE TABLE IF NOT EXISTS rankings (
  player_id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  time_ms INTEGER NOT NULL,
  class_name TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_rankings_time ON rankings(time_ms ASC, created_at ASC);
